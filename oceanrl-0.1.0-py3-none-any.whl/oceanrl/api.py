from . import _internal_math as _

def query(salmon_t, shark_t, fishing_effort_t, month_t):
    return _.update_populations(salmon_t, shark_t, fishing_effort_t, month_t)


def main():
    import argparse, json
    p = argparse.ArgumentParser()
    p.add_argument("--salmon", type=float, required=True)
    p.add_argument("--shark", type=float, required=True)
    p.add_argument("--effort", type=float, required=True)
    p.add_argument("--month", type=int, required=True)
    a = p.parse_args()
    out = query(a.salmon, a.shark, a.effort, a.month)
    print(json.dumps({
        "salmon_caught": float(out[0]),
        "salmon_t_plus_1": float(out[1]),
        "shark_t_plus_1": float(out[2]),
    }))